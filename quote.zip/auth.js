/**
 * routes/auth.js
 * POST /api/v1/auth/login
 * POST /api/v1/auth/logout
 * GET  /api/v1/auth/me
 * PUT  /api/v1/auth/password
 */
import { Router } from 'express';
import { body } from 'express-validator';
import { authenticate } from '../middleware/auth.js';
import { validateRequest } from '../middleware/errorHandler.js';
import { loginUser, logoutUser, changePassword } from '../services/authService.js';

const router = Router();

// ── POST /login ──────────────────────────────────────────────────────────────
router.post('/login',
  body('email').isEmail().normalizeEmail().withMessage('Email non valida.'),
  body('password').notEmpty().withMessage('Password obbligatoria.'),
  validateRequest,
  async (req, res, next) => {
    try {
      const result = await loginUser(req.body.email, req.body.password, {
        ip:        req.ip,
        userAgent: req.headers['user-agent'],
      });
      res.json(result);
    } catch (err) { next(err); }
  }
);

// ── POST /logout ─────────────────────────────────────────────────────────────
router.post('/logout', authenticate, async (req, res, next) => {
  try {
    const token = req.headers.authorization?.slice(7);
    if (token) await logoutUser(token);
    res.json({ message: 'Logout effettuato.' });
  } catch (err) { next(err); }
});

// ── GET /me ──────────────────────────────────────────────────────────────────
router.get('/me', authenticate, (req, res) => {
  const { id, name, email, role } = req.user;
  res.json({ id, name, email, role });
});

// ── PUT /password ────────────────────────────────────────────────────────────
router.put('/password',
  authenticate,
  body('currentPassword').notEmpty().withMessage('Password attuale obbligatoria.'),
  body('newPassword').isLength({ min: 8 }).withMessage('Nuova password: minimo 8 caratteri.'),
  validateRequest,
  async (req, res, next) => {
    try {
      await changePassword(req.user.id, req.body.currentPassword, req.body.newPassword);
      res.json({ message: 'Password aggiornata. Effettua di nuovo il login.' });
    } catch (err) { next(err); }
  }
);

export default router;
